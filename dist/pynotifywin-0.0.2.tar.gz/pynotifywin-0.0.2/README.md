`# PyNotify

A libary designed for Windows (with planned linux support), that allows you to create every type of standard desktop notification you can imagine!

![](./img1.png)
![](./img2.png)


<h2 cstyle="text-align: center;"><bold>Created by Nerd Bear</bold></h2>

Disclamer: Even though the code is made by humans, certain docstrings were created by AI VSC extensions.`